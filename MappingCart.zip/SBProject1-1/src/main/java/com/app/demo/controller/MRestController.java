package com.app.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.demo.dao.MDAO;

@RestController
@RequestMapping("/rest/api")
@Transactional
public class MRestController 
{
		@Autowired
		MDAO dao;
	
		@GetMapping("/doMappings")
		public boolean doMapping()
		{
			dao.doSomething();
			return true;
		}
}
