package com.app.demo.pojos;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "prdx001")
public class Product 
{
		@Id
		private String prodid;
		
		private String prodname;
		
		@ManyToMany(mappedBy = "product")
		List<Cart> cart;
		

		public List<Cart> getCart() {
			return cart;
		}

		public void setCart(List<Cart> cart) {
			this.cart = cart;
		}

		public String getProdid() {
			return prodid;
		}

		public void setProdid(String prodid) {
			this.prodid = prodid;
		}

		public String getProdname() {
			return prodname;
		}

		public void setProdname(String prodname) {
			this.prodname = prodname;
		}
		
	
		
		
}
