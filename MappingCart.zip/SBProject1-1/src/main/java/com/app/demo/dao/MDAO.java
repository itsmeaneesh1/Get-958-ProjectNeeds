package com.app.demo.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.demo.pojos.Cart;
import com.app.demo.pojos.Customer;
import com.app.demo.pojos.Product;

@Repository
public class MDAO {
	
	@Autowired
	EntityManager em;
	
	public void doSomething()
	{
		System.out.println("TEST");
		
		Customer c=new Customer();
		c.setCustid("C001");
		c.setCustName("Rahul");
		
		Customer c2=new Customer();
		c2.setCustid("C002");
		c2.setCustName("Ravi");
		
		Product p=new Product();
		p.setProdid("P001");
		p.setProdname("ABC");
		
		Product p2=new Product();
		p2.setProdid("P002");
		p2.setProdname("CAD");
		
		List<Product> prodList=new ArrayList<Product>();
		prodList.add(p) ; prodList.add(p2);
		
		List<Product> prodList2=new ArrayList<Product>();
		prodList2.add(p) ; prodList2.add(p2);
		
		Cart cart1=new Cart();
		cart1.setCartId("CART001");
		cart1.setCustomerid(c);
		cart1.setQty(10);
		cart1.setProduct(prodList);
		
		
		
		Cart cart2=new Cart();
		cart2.setCartId("CART002");
		cart2.setCustomerid(c2);
		cart2.setQty(30);
		cart2.setProduct(prodList2);
		
		//em.merge(cart1);
		//em.merge(cart2);
		em.persist(cart1);
		em.persist(cart2);
	
		System.out.println("Done");
		
	}

}
