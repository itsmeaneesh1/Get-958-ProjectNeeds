package com.app.demo.pojos;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "cartx001")
public class Cart {
	
	@Id
	private String cartId;
	
	@OneToOne(cascade = CascadeType.ALL)
	Customer customerid;
	
	private int qty;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "cartx_cartItems" , joinColumns = {
			  @JoinColumn(name = "CART_ID",referencedColumnName = "cartId",nullable = true)
	  },
	  inverseJoinColumns = {
			  @JoinColumn(name = "PROD_ID",referencedColumnName = "prodid",nullable = true)
	  }
	  )
	List<Product> product;

	public String getCartId() {
		return cartId;
	}

	public void setCartId(String cartId) {
		this.cartId = cartId;
	}

	public Customer getCustomerid() {
		return customerid;
	}

	public void setCustomerid(Customer customerid) {
		this.customerid = customerid;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public List<Product> getProduct() {
		return product;
	}

	public void setProduct(List<Product> product) {
		this.product = product;
	}

	
	
	
	
}
