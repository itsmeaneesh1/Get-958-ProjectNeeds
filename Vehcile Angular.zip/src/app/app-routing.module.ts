import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { NewvehicleComponent } from './newvehicle/newvehicle.component';
import { SearchvehicleComponent } from './searchvehicle/searchvehicle.component';
import { ShowvehiclesComponent } from './showvehicles/showvehicles.component';

const routes: Routes = [
    {path:'addvehicle',component:NewvehicleComponent},
    {path:'showall',component:ShowvehiclesComponent},
    {path: 'login',component:LoginComponent},
    {path:'gohome',component:HomeComponent},
    {path:'search',component:SearchvehicleComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
