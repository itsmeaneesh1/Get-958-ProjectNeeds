import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Vehicle } from './vehicle';
@Injectable({
  providedIn: 'root'
})
export class VehicleService {

  constructor(private myhttp:HttpClient) { }

  restUrl:string="http://localhost:9097/rest/api";

  getAllVehicles()
  {
      return this.myhttp.get(this.restUrl+"/vehicle")
  }
 
  addVehicle(veh:Vehicle)
  {

      return this.myhttp.post(this.restUrl+"/vehicle",veh);
  }
  validateLogin(logValues:any)
  {
        return this.myhttp.get(this.restUrl+"/validatelogin/"+logValues.loginid+"/"+logValues.passwd);
  }
  searchvehicles(srchText:any)
  {
       return this.myhttp.get(this.restUrl+"/vehiclebymaker/"+srchText);
  }
}
