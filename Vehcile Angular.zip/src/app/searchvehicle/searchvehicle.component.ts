import { Component, OnInit } from '@angular/core';
import { VehicleService } from '../vehicle.service';

@Component({
  selector: 'app-searchvehicle',
  templateUrl: './searchvehicle.component.html',
  styleUrls: ['./searchvehicle.component.css']
})
export class SearchvehicleComponent implements OnInit {

  srchText:any;
  vehicleList:any;
  constructor(private vhs:VehicleService) { }

  ngOnInit(): void {
  }
  search()
  {
      this.vhs.searchvehicles(this.srchText).subscribe(
        (data)=>{
              console.log(data);
              this.vehicleList=data;
        }
      )
  }

}
