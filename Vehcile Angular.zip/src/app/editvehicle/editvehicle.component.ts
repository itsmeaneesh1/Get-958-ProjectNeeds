import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editvehicle',
  templateUrl: './editvehicle.component.html',
  styleUrls: ['./editvehicle.component.css']
})
export class EditvehicleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
