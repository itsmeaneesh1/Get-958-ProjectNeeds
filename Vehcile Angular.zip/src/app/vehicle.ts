export class Vehicle
{
        vid:string|undefined;
        vname:string|undefined;
        type:string|undefined;
        manufac:string|undefined;
}
