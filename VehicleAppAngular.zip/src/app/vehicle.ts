export class Vehicle 
{
    vehicleNo:string|undefined;
     vehicleType: string|undefined;
     modelName:string |undefined; 
}
