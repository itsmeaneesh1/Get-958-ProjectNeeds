import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NewvehicleComponent } from './newvehicle/newvehicle.component';
import { SearchComponent } from './search/search.component';
import { ShowallComponent } from './showall/showall.component';
import { UpdatevehicleComponent } from './updatevehicle/updatevehicle.component';

const routes: Routes = [
  {path:'addvehicle' ,component:NewvehicleComponent},
  {path:'showall' ,component:ShowallComponent},
  {path:'search',component:SearchComponent},
  {path:'updatevehicle/:vehicleNo',component:UpdatevehicleComponent} //Step 1
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
